﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using PromotionEngine.Interface;
using PromotionEngine.Management.Interface;
using PromotionEngine.Management.Services;
using PromotionEngine.Services;

[assembly: FunctionsStartup(typeof(PromotionEngine.Management.Startup))]
namespace PromotionEngine.Management
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddSingleton<IPromotionService, PromotionService>();
            builder.Services.AddSingleton<IPromotionOfferService, PromotionOfferService>();
        }
    }
}

