﻿using PromotionEngine.Management.Interface;
using PromotionEngine.Management.Models;
using System.Collections.Generic;

namespace PromotionEngine.Interface
{
    public interface IPromotionService
    {
        List<SKUList> GetSkus();
        int CheckOut(List<Cart> cart, IPromotionOfferService offerService);
    }
}
