﻿using Newtonsoft.Json;

namespace PromotionEngine.Management.Models
{
    public class RequestError
    {
        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "responsecode")]
        public int ResponseCode { get; set; }

        [JsonProperty(PropertyName = "error")]
        public string Error { get; set; }
    }
}
