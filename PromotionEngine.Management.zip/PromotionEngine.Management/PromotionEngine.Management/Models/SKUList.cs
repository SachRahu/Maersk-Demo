﻿namespace PromotionEngine.Management.Models
{
    public class SKUList
    {
        public string Item { get; set; }
    }
}
