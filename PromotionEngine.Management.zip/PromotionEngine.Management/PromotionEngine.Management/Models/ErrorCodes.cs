﻿using System.Net;

namespace PromotionEngine.Management.Models
{
    public static class BadRequest
    {
        public static string Message = "An issue occured with this request";
        public static int Code = (int)HttpStatusCode.BadRequest;
        public static string Title = "Bad Request";
    }
    public static class NotFound
    {
        public static string Message = "Not Found";
        public static int Code = (int)HttpStatusCode.NotFound;
        public static string Title = "Not Found";
    }
    public static class Internal
    {
        public static string Message = "Internal Server Error";
        public static int Code = (int)HttpStatusCode.InternalServerError;
        public static string Title = "Error";
    }
}
