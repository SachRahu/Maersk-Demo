﻿using PromotionEngine.Interface;
using PromotionEngine.Management.Interface;
using PromotionEngine.Management.Models;
using PromotionEngine.Management.Utils;
using System.Collections.Generic;
using System.Linq;

namespace PromotionEngine.Services
{
    public class PromotionService : IPromotionService
    {
        public int CheckOut(List<Cart> carts,IPromotionOfferService offerService)
        {
            int total = 0;

            var skuCDs = carts.Where(o => o.SKU == SKUEnum.C.ToString() || (o.SKU.Contains(SKUEnum.D.ToString())));
            foreach (var cart in carts)
            {
                switch (cart.SKU)
                {
                    case "A":
                        total = total + offerService.PromotionAOffer(cart.Quantity, Settings.PramotionASKUUnit, Settings.PramotionAOfferValue, Settings.PramotionAValue);
                        break;
                    case "B":
                        total = total + offerService.PromotionBOffer(cart.Quantity, Settings.PramotionBSKUUnit, Settings.PramotionBOfferValue, Settings.PramotionBValue);
                        break;                        
                }
            }

            if(skuCDs.Count() > 0)
            {
                total = total + offerService.PromotionCDOffer(skuCDs);
            }
            
            return total;
        }

        public List<SKUList> GetSkus()
        {
            var items = new List<SKUList>();
            items.Add((new SKUList { Item = "A" }));
            items.Add((new SKUList { Item = "B" }));
            items.Add((new SKUList { Item = "C" }));
            items.Add((new SKUList { Item = "D" }));
            return items;
        }
    }
}
