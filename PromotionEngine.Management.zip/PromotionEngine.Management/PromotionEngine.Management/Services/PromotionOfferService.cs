﻿using PromotionEngine.Management.Interface;
using PromotionEngine.Management.Models;
using PromotionEngine.Management.Utils;
using System.Collections.Generic;
using System.Linq;

namespace PromotionEngine.Management.Services
{
    public class PromotionOfferService : IPromotionOfferService
    {
        public int PromotionAOffer(int quantity, int pramotionASKUUnit, int pramotionAOfferValue, int pramotionAValue)
        {
            if (quantity >= pramotionASKUUnit)
            {
                var div = quantity / pramotionASKUUnit;
                var mod = quantity % pramotionASKUUnit;
                return (div * pramotionAOfferValue) + (mod * pramotionAValue);
            }
            else
            {
                return quantity * pramotionAValue;
            }
        }

        public int PromotionBOffer(int quantity, int pramotionASKUUnit, int pramotionAOfferValue, int pramotionAValue)
        {
            if (quantity >= pramotionASKUUnit)
            {
                var div = quantity / pramotionASKUUnit;
                var mod = quantity % pramotionASKUUnit;
                return (div * pramotionAOfferValue) + (mod * pramotionAValue);
            }
            else
            {
                return quantity * pramotionAValue;
            }
        }

        public int PromotionCDOffer(IEnumerable<Cart> skuCDs)
        {
            var total = 0;
            if ((skuCDs.Where(o => o.SKU == "C").Select(o => o.Quantity).FirstOrDefault() >= 1 && (skuCDs.Where(o => o.SKU == "D").Select(o => o.Quantity).FirstOrDefault() >= 1)))
            {
                total = Settings.PramotionCDOfferValue;
                //var CProduct = skuCDs.Where(o => o.SKU == "C").Select(o => o.Quantity).FirstOrDefault();
                //CProduct = CProduct - 1;
                //var DProduct = skuCDs.Where(o => o.SKU == "D").Select(o => o.Quantity).FirstOrDefault();
                //DProduct = DProduct - 1;
            }
            else if ((skuCDs.Where(o => o.SKU == "C").Select(o => o.Quantity).FirstOrDefault() == 1))
            {
                total = Settings.PramotionCValue;
            }
            else if ((skuCDs.Where(o => o.SKU == "D").Select(o => o.Quantity).FirstOrDefault() == 1))
            {
                total = Settings.PramotionDValue;
            }
            return total;
        }
    }
}
