using PromotionEngine.Interface;
using PromotionEngine.Management.Interface;
using PromotionEngine.Management.Models;
using PromotionEngine.Management.Services;
using PromotionEngine.Services;
using System.Collections.Generic;
using Xunit;

namespace PromotionEngine.Management.Test
{
    public class PromotionEngineTest
    {
        private readonly IPromotionService _promotionService;
        private readonly IPromotionOfferService _offerService;
        public PromotionEngineTest()
        {
            _promotionService = new PromotionService();
            _offerService = new PromotionOfferService();
        }

        [Fact]
        public void ScenarioA()
        {
            var cartList = new List<Cart>();
            cartList.Add(new Cart { SKU = "A", Quantity = 1 });
            cartList.Add(new Cart { SKU = "B", Quantity = 1 });
            cartList.Add(new Cart { SKU = "C", Quantity = 1 });
            var result = _promotionService.CheckOut(cartList, _offerService);
            Assert.Equal(100, result);
        }

        [Fact]
        public void ScenarioB()
        {
            var cartList = new List<Cart>();
            cartList.Add(new Cart { SKU = "A", Quantity = 5 });
            cartList.Add(new Cart { SKU = "B", Quantity = 5 });
            cartList.Add(new Cart { SKU = "C", Quantity = 1 });          
            var result = _promotionService.CheckOut(cartList, _offerService);
            Assert.Equal(370, result);
        }

        [Fact]
        public void ScenarioC()
        {
            var cartList = new List<Cart>();
            cartList.Add(new Cart { SKU = "A", Quantity = 3 });
            cartList.Add(new Cart { SKU = "B", Quantity = 5 });
            cartList.Add(new Cart { SKU = "C", Quantity = 1 });
            cartList.Add(new Cart { SKU = "D", Quantity = 1 });
            var result = _promotionService.CheckOut(cartList, _offerService);
            Assert.Equal(280, result);
        }
    }
}
